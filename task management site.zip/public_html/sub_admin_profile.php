<?php include 'connection.php';
  session_start();

  if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
$email = $_SESSION['admin_email'];
?>

<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Lord Bakayarou - Profile</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">

  <style media="screen">
  #img {
border-radius: 50%;
display: block;
margin-left: auto;
margin-right: auto;
}
  </style>

</head>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion toggled" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php">
        <div class="sidebar-brand-icon rotate-n-15">
          <i class="fas fa-feather-alt"></i>
        </div>
        <div class="sidebar-brand-text mx-3">Lord Bakayarou</div>
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <li class="nav-item active">
        <a class="nav-link" href="index.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span></a>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Heading -->
      <div class="sidebar-heading">
        Interface
      </div>

      <li class="nav-item">
        <a class="nav-link" href="manage_patron.php">
          <i class="fas fa-fw fa-child"></i>
          <span>Patron</span></a>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Heading -->
      <div class="sidebar-heading">
        User & Task Management
      </div>

      <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages" aria-expanded="true" aria-controls="collapsePages">
          <i class="fas fa-fw fa-users"></i>
          <span>Users</span>
        </a>
        <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">User Action's</h6>
            <a class="collapse-item" href="user.php">Add User</a>
            <a class="collapse-item" href="manage_user.php">Manage User</a>
          </div>
        </div>
      </li>

      <!-- Nav Item - Tables -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePagesTask" aria-expanded="true" aria-controls="collapsePagesTask">
          <i class="fas fa-fw fa-tasks"></i>
          <span>Tasks</span>
        </a>
        <div id="collapsePagesTask" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Task Action's</h6>
            <a class="collapse-item" href="task.php">Add Task</a>
            <a class="collapse-item" href="manage_task.php">Manage Task</a>
          </div>
        </div>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">

      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

    </ul>
    <!-- End of Sidebar -->



    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>


              <img src="images/logo.png"  width="200" height="40">



          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">

            <div class="topbar-divider d-none d-sm-block"></div>

            <!-- Nav Item - User Information -->

            <?php
            $sql = "SELECT * FROM `loginpage`  WHERE email = '$email' "  ;

            $result = mysqli_query($conn, $sql);
            $row = mysqli_fetch_assoc($result);
            $image = $row['name'];
            echo $name;
            ?>
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo $_SESSION['admin_email']; ?></span>
                <img class="img-profile rounded-circle" src="uploads/<?php echo $image ?>" alt="https://source.unsplash.com/QAB-WJcbgJk/60x60">
              </a>

              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                <a class="dropdown-item" href="#">
                  <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                  User : <?php echo $_SESSION['admin_email']; ?>
                </a>

                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>



          </ul>

        </nav>
        <!-- End of Topbar -->

        <?php
          include 'config.php';
          $target_dir = "uploads/";
          $name  =$_FILES["fileToUpload"]["name"];
          $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
          $uploadOk = 1;
          $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

          // Check if image file is a actual image or fake image
          if(isset($_POST["submit"])) {
            $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
            if($check !== false) {
              // echo "File is an image - " . $check["mime"] . ".";
              $uploadOk = 1;
            } else {
              // echo "File is not an image.";
              $uploadOk = 0;
            }
          }


          // Check file size
          if ($_FILES["fileToUpload"]["size"] > 500000) {
            // echo "Sorry, your file is too large.";
            $uploadOk = 0;
          }

          // Allow certain file formats
          if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
          && $imageFileType != "gif" ) {
            // echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
            $uploadOk = 0;
          }

          // Check if $uploadOk is set to 0 by an error
          if ($uploadOk == 0) {
            // echo "Sorry, your file was not uploaded.";
          // if everything is ok, try to upload file
          } else {
            if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {

              $sql =   "UPDATE `loginpage` SET `name` = '$name' WHERE `loginpage`.`email` = '$email' ";


           if(mysqli_query($conn, $sql)){
              echo "<script> window.location= 'sub_admin_profile.php'</script>";

            }

              // echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
            } else {
              // echo "Sorry, there was an error uploading your file.";
            }
          }

            ?>

        <!-- Begin Page Content -->
        

          <div class="container-fluid">
            <form action="" method = "POST" enctype="multipart/form-data">

            <!-- Page Heading -->
            <h1 class="h3 mb-2 text-gray-800">Tasks</h1>
            <div class="shadow p-3 mb-5 bg-white rounded">

              <img src="uploads/<?php echo $image ?>" class="" id="img" style="width:250px">

              <table align="center">

            </table>
              <table align="center">
                <tr>
                  <td></td>

                 <td><label align = "right">Change Photo
                <i class="fas fa-upload"></i>
                <input type="file" accept="image/*" class="form-control"name="fileToUpload" id="fileToUpload" value="" style="visibility: hidden;" required> </td>
                </label></td>
                </tr>
                <br>
                <tr>

                  <td>FirstName</td>
                  <?php
                  $sql = "SELECT * FROM `loginpage`  WHERE email = '$email' "  ;

                  $result = mysqli_query($conn, $sql);
                  $row = mysqli_fetch_assoc($result);
                  ?>
                  <td> <input type="text" class="form-control" name="subject" value="<?php echo $row["firstname"];?>" disabled> </td>
                </tr>
                <tr>

                  <td>LastName</td>

                  <td> <input type="text" class="form-control" name="subject" value="<?php echo $row["lastname"];?>" disabled> </td>
                </tr>
                <tr>
                  <td>Phone</td>
                  <td> <input type="text" class="form-control" name="subject" value="<?php echo $row["phone"];?>" disabled> </td>
                </tr>
                <tr>
                  <td>Email</td>
                  <td>
                    <input type="text" class="form-control" name="subject" value="<?php echo $row["email"];?>" disabled>
                  </td>
                </tr>

                <tr>
                  <td>
                  </td>
                  <td>
                    <input type="submit" class="btn btn-success btn-sm" name="submit" value="Submit">
                  </td>
                </tr>
              </table>
              <br>
          </div>
        </form>
          </div>


      
      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; Your Website 2020</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">
            Cancel</button>


          <a class="btn btn-primary" href="admin_logout.php">Logout</a>

        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/chart.js/Chart.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/chart-area-demo.js"></script>
  <script src="js/demo/chart-pie-demo.js"></script>

</body>

</html>
