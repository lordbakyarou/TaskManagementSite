<?php
include 'config.php';
session_start();
$email = "";
$pass = "";
// Grab User submitted information
if (isset($_POST['loginbutton'])) {
$email = $_POST['username'];
$pass = $_POST['password'];
}

$result = mysqli_query($mysqli, "SELECT * FROM user_login WHERE username='$email' AND password='$pass'");
while($row = mysqli_fetch_array($result)){
     $name = $row['name'];
}

if (mysqli_num_rows($result) == 1){
  $_SESSION["session_id"] = "1";
  $_COOKIE['username'] = $email;
  $_SESSION['name'] = $name;
  $_SESSION["id"] = $id;
  $_SESSION['success'] = "You are now logged in";
  header('location: userpage.php');

  }
else{

}
?>
