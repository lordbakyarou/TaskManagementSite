<?php
session_start();
unset($_SESSION["session_id"]);
header("Location:user_login.php");
?>
