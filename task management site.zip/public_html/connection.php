<?php
$servername = "localhost";
$username = "id14756614_mikenorvak17";
$password = "Mayurhanwate@123";
$database = "id14756614_main_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?>
