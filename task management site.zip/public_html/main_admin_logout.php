<?php
session_start();
unset($_SESSION["session_id_admin"]);
header("Location:admin.php");
?>
